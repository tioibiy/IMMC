#include<bits/stdc++.h>
#define LL long long
#define DB double
#define IT set<node>::iterator
using namespace std;
int b;
int main(){
    cout<<"Hello World";
    cout<<"1";
    return 0;
}